import matplotlib.pyplot as plt

sent_count: int = 0
received_count: int = 0
pings: list[float] = []

file_input = open('ubuntu.com - 185.125.190.20.txt', 'r')
for line in file_input:
    received_count += 1

    [index, time] = line.split(',')
    while len(pings) != int(index):
        pings.append(0.0)
    pings.append(float(time))

sent_count = len(pings)
file_input.close()

# 1. delivery rate
delivery_rate: float = received_count / sent_count
print('Overall delivery rate:', delivery_rate)

# 2. longest consecutive string of successful pings
# 3. longest burst losses
longest_successful: int = 0
longest_loss: int = 0
for ping in pings:
    if ping == 0.0:
        longest_successful = 0
        longest_loss += 1
    else:
        longest_loss = 0
        longest_successful += 1
print('Longest consecutive successful pings:', longest_successful)
print('Longest burst losses:', longest_loss)

# 4. pass, since there's no burst losses in data from ubuntu.com

# 5. (approximate) min RTT
# 6. max RTT
min_rtt: float = float('inf')
max_rtt: float = float('-inf')
for ping in pings:
    if ping < min_rtt and ping != 0.0:
        min_rtt = ping
    if ping > max_rtt:
        max_rtt = ping
print('Min RTT:', min_rtt)
print('Max RTT:', max_rtt)

# 7. RTT graph over time
graph_y: list[float] = []
graph_x: list[float] = []
for (i, ping) in enumerate(pings):
    if ping == 0.0:
        continue
    graph_y.append(ping)
    graph_x.append( i / sent_count * 2 )
plt.plot(graph_x, graph_y)
plt.title('RTT over time')
plt.xlabel('Time [hour]')
plt.ylabel('RTT [ms]')
plt.show()

# 8. histogram of RTT
plt.hist(graph_y, bins=50, log=False)
plt.title('RTT distribution')
plt.show()

# 9. correlation between ping #N and ping #N+1
graph_xx: list[float] = [ping if ping != 0.0 else float('inf') for ping in pings]
graph_yy: list[float] = graph_xx[1:]
graph_xx = graph_xx[:-1]
plt.scatter(graph_xx, graph_yy)
plt.title('RTT correlation between #N and #N+1')
plt.xlabel('#N')
plt.ylabel('#N+1')
plt.show()