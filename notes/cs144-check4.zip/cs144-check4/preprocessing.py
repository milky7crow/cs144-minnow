import re

file_input = open('data.txt', 'r')

match = re.search(r'PING (.*) \((.*)\)', file_input.readline())
hostname: str = match.group(1)
ip: str = match.group(2)

file_output = open(f'{hostname} - {ip}.txt', 'w')
pings: list[float] = []

for line in file_input:
    match = re.search(r'icmp_seq=(\d+).*time=(\d+\.\d+) ms', line)
    seq: int = int(match.group(1))
    time: float = float(match.group(2))
    file_output.write(f'{seq},{time}\n')

file_output.close()
file_input.close()
